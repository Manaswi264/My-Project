
public class typeCasting {
public static void main(String[] args) {
	System.out.println("Implicit Type Casting");
	char x='X';
	System.out.println("value of x:" +x);
	int z=x;
	System.out.println("value of z:"+z);
	
	float a=x;
	System.out.println("value of a:"+a);
	
	double b=x;
	System.out.println("value of b:"+b);
	 
	
	System.out.println("\n");
	
	
	System.out.println("Explicit type casting");
	
	double j=20.5;
	int k= (int) j;
	
	System.out.println("value of j:"+j);
	System.out.println("value of k:"+k);
	
	
	
} 

}
